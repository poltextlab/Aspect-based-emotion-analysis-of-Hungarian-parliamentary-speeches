import hu_core_news_lg

########################################################################################################################
#   Use only after 'train_test_data.txt' is generated,
#   and if you want to (de)select arguments from train data by filtering to POS
########################################################################################################################

# Set these variables:
# train_test.txt:
data = "/home/istvanu/Asztal/szakdoga/train_test_data.txt"
# folder for the resulted (filtered) train-test data:
output_folder = "/home/istvanu/Asztal/szakdoga/"
# set the desired POS tag, that you expect to be present in every "argument" (aspect)
obligatory_POS = [["NOUN"], ["PRON"], ["PROPN"]]

# Prerequisite: pip install https://huggingface.co/huspacy/hu_core_news_lg/resolve/main/hu_core_news_lg-any-py3-none-any.whl

# Do not modify below!
########################################################################################################################


def main():
    nlp = hu_core_news_lg.load()
    with open(data, 'r', encoding='utf8') as original:
        original_lines = original.readlines()

    filtered_sentences = []
    obligatory_POS_list = [item for sublist in obligatory_POS for item in sublist]

    for i in range(1, len(original_lines), 3):
        doc = nlp(original_lines[i])
        pos_tags = []
        for sentence in doc.sents:
            for token in sentence:
                pos_tags.append(token.pos_)

        intersection = set(obligatory_POS_list).intersection(set(pos_tags))

        if not intersection:
            continue
        else:
            filtered_sentences.append(original_lines[i-1])
            filtered_sentences.append(original_lines[i])
            filtered_sentences.append(original_lines[i+1])
        print(i)

    with open(output_folder + "POS_filtered_train_test_data.txt", 'w', encoding='utf8') as result:
        for item in filtered_sentences:
            print(item)
            result.write(item)
            # result.write('\r\n')


if __name__ == '__main__':
    main()
