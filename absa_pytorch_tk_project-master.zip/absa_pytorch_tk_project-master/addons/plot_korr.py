import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from scipy import stats

elemek = [2564, 1653, 1570, 908, 216, 158, 114, 52, 51, 30, 14, 9]
f1_ek = [0.77, 0.64, 0.53, 0.38, 0.38, 0.44, 0.51, 0.35, 0.41, 0.16, 0.21, 0.00]

df = pd.DataFrame(list(zip(elemek, f1_ek)), columns=['Elemszam', 'F1_Score'])

ax = sns.scatterplot(x='Elemszam', y='F1_Score', data=df)
sns.lmplot(x='Elemszam', y='F1_Score', data=df)
ax.set_title("Kategóriák elemszámainak összefüggése a mért átlagos F-értékekkel")
plt.savefig('/home/istvanu/Asztal/plot-png')

print(stats.pearsonr(df['Elemszam'], df['F1_Score']))