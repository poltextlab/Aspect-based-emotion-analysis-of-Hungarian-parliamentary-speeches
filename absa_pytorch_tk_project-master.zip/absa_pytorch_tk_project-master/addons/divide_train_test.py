import pandas as pd
from sklearn.model_selection import train_test_split


full_dataset_txt = "/home/istvanu/Asztal/szakdoga/POS_filtered_train_test_data.txt"
test_file = "/home/istvanu/Asztal/szakdoga/OpinHuBank_Test.txt"
train_file = "/home/istvanu/Asztal/szakdoga/OpinHuBank_Train.txt"


def main():

    list_of_rows = []
    with open(full_dataset_txt, 'r', encoding='utf8') as full_data:
        lines = full_data.readlines()
        for i in range(2, len(lines), 3):
            df2 = {'Sentence': lines[i-2], 'Argument': lines[i-1], 'Emotion': lines[i].replace("e_", "")}
            list_of_rows.append(df2)
    all_data = pd.DataFrame.from_records(list_of_rows, columns=['Sentence', 'Argument', 'Emotion'])
    # print(all_data.head(5))
    train, test = train_test_split(all_data, test_size=0.2, stratify=all_data[['Emotion']])

    with open(test_file, 'w', encoding='utf8') as test_sentences:
        for index, row in test.iterrows():
            test_sentences.write(row['Sentence'])
            test_sentences.write(row['Argument'])
            test_sentences.write(row['Emotion'])

    with open(train_file, 'w', encoding='utf8') as train_sentences:
        for index, row in train.iterrows():
            train_sentences.write(row['Sentence'])
            train_sentences.write(row['Argument'])
            train_sentences.write(row['Emotion'])


if __name__ == '__main__':
    main()
