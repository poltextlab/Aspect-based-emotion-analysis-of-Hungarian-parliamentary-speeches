from src.pairing import Pairing
from src.txt_json_pair import TxtJsonPair
from src import train_test_sentence_creator
from src import clustered_train_test_generator
from typing import List


# Where are the .txt and .json files?
txt_and_json_folder = "/home/istvanu/Asztal/szakdoga/omleszetett_LREC/"
# Where the files generated during the process should be written? (e.g.: txt - json pairs [filenames] in a .txt format)
WORKING_FOLDER = "/home/istvanu/Asztal/szakdoga/test_data/"

# Set True, if txt - json pairs have been found previously
# (otherwise the program will search for the already existing /PAIRS.txt in WORKING_FOLDER)
pairs_already_found = False

#Set true, if a sentence can appear in the data with more than one instances, with different arguments
clustered_data = True
test_file = "/home/istvanu/Asztal/szakdoga/OpinHuBank_Test.txt"
train_file = "/home/istvanu/Asztal/szakdoga/OpinHuBank_Train.txt"

########################################################################################################################
# DO NOT MODIFY BELOW!

TRAIN_TEST_SENTENCES_LIST_OF_LISTS = []
ET_SENTENCE_CLUSTERS_DICT = {}


def main():

    # create a dict with {txt_file_name : json_file_name } pairs
    txt_json_pairs_dict = load_txt_json_pairs()
    print("txt-json pairs generated")

    # List to store TxtJsonPair objects, which contains the Text of txt, and lists of Entitiy and Relation objects
    # corresponding to the given txt ( -json pair)
    text_and_annotations = get_txt_json_pair_objects(txt_json_pairs_dict)
    print("txtJsonPair objects ready")
    init()

    # Use this, if only those sentences should add to train/test set in which only ONE kind of ET appears!
    for text_and_annotation_object in text_and_annotations:
        # print(text_and_annotation_object)
        # get "original" data structure, while populate ET_SENTENCE_CLUSTERS_DICT
        result, train_test_sentences = train_test_sentence_creator.create_train_test_sentences(text_and_annotation_object, ET_SENTENCE_CLUSTERS_DICT)
        for instance in train_test_sentences:
            TRAIN_TEST_SENTENCES_LIST_OF_LISTS.append(instance)
    print("raw train test sentences generated")

    if clustered_data:
        # calculate train_test_set for each emotion topic, then write train and test files directly!
        clustered_train_test_generator.generate(ET_SENTENCE_CLUSTERS_DICT, test_file, train_file)
        print("Clustered generation successfull!")
    else:
        write_train_test_file(TRAIN_TEST_SENTENCES_LIST_OF_LISTS, WORKING_FOLDER + "/train_test_data.txt")
        print("Generation successful!")


def init():
    """

    :return:
    """

    # Create ET_SENTENCE_CLUSTERS_DICT, which contains all "variants" of a sentence, under the key of it's emotion topic
    # Each key contains a list of lists;
    # { '1': [[This is a bad $T$ and even worst timing, idea, e_2]]
    # }

    for i in range(1, 13):
        ET_SENTENCE_CLUSTERS_DICT[str(i)] = []


def write_train_test_file(train_test_sentences_list_of_lists, wheretowrite):
    with open(wheretowrite, 'w', encoding='utf8') as result:
        for instance in train_test_sentences_list_of_lists:
            for lines in instance:
                for line in lines:
                    result.write(line)
                    result.write('\r\n')


def get_txt_json_pair_objects(txt_json_pairs_dict: dict) -> List:
    """
    Function to create a list of 'TxtJsonPair' objects from text and json files.

    :param txt_json_pairs_dict: Dictionary of already paired txt and json (annotation) files
    :return:
    """

    text_and_annotations = []

    for txt_name, json_name in txt_json_pairs_dict.items():
        txt_path = txt_and_json_folder + txt_name
        json_path = txt_and_json_folder + json_name

        txt_json_pair = TxtJsonPair(txt_path, json_path)
        txt_json_pair.start()

        text_and_annotations.append(txt_json_pair)

    return text_and_annotations


def load_txt_json_pairs() -> dict:
    """
    IF txt - json pairs not found already, the creates a dict with these pairs in 'txt_and_json_folder' global variable,
    then save this dict as 'PAIRS.txt' to path pointed by 'WORKING_FOLDER' global variable
    ELSE reads the txt - json pairs from 'PAIRS.txt' from 'WORKING_FOLDER'

    :return: Dictionary contains all txt-json pairs, e.g.: {'20142018_003_0002_0002_LMP.txt': 'aP_HvCV8dBea4Ac2ctw1LxC155Ca-20142018_003_0002_0002_LMP.txt.ann.json'}
    """

    pairs = {}

    if not pairs_already_found:
        pairing = Pairing(txt_and_json_folder, WORKING_FOLDER)
        pairing.find_txt_names()                                     # 1.) keressük meg az összetartozó fájlneveket!
        pairing.find_txts_with_corresponding_json()                  # 2.)  nézzük meg, hogy mely txt-khez tartozik json (és mennyi; 1 v. több?)
        pairing.find_txt_json_pairs()                                # 3.) párosítsuk össze a txt-t a megfelelő json annotációval
        pairs = pairing.write_pairs()                                # 4.) ha egyszer megtaláltuk, írjuk ki a párosításokat
    else:
        with open(WORKING_FOLDER + "PAIRS.txt", 'r', encoding='utf-8') as pair_file:
            lines = pair_file.readlines()
            for line in lines:
                tmp = line.split("\t")
                pairs[tmp[0]] = tmp[1].replace('\n', '')             # save {txt : json} filenames in a dict
    return pairs


if __name__ == '__main__':
    main()
