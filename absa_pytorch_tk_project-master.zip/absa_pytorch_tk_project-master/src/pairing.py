import os


class Pairing(object):
    """
    Results a dictionary with txt, json pairs, e.g.:

    {'20142018_003_0002_0002_LMP.txt': 'aP_HvCV8dBea4Ac2ctw1LxC155Ca-20142018_003_0002_0002_LMP.txt.ann.json'}

    Key:    txt file name
    Value:  corresponding json file name

    """

    def __init__(self, txt_and_json_folder: str, result_folder: str):
        self._txt_and_json_folder = txt_and_json_folder
        self._result_folder = result_folder
        self.TXT_FILENAMES = []
        self._txts_with_corresponding_json_file = {}
        self._txt_json_pairs = {}

    def find_txt_names(self) -> None:
        """
        Finds all files ending with '.txt' in 'self._txt_and_json_folder' -folder stored in self._txt_and_json_folder
        class variable. Saves this list to 'self.TXT_FILENAMES' class variable.

        :return: None
        """
        for filename in os.listdir(self._txt_and_json_folder):
            f = os.path.join(self._txt_and_json_folder, filename)
            if os.path.isfile(f) and f.endswith('.txt'):
                self.TXT_FILENAMES.append(filename.replace(".txt", ""))

    def find_txts_with_corresponding_json(self) -> None:
        """
        Finds all txt-s that have an existing annotation (json) file in folder pointed by 'self._txt_and_json_folder class'
        variable.

        :return: None
        """

        for txt in self.TXT_FILENAMES:
            for json_filename in os.listdir(self._txt_and_json_folder):
                f = os.path.join(self._txt_and_json_folder, json_filename)
                if os.path.isfile(f) and f.endswith('.json'):
                    if txt in json_filename:
                        if txt in self._txts_with_corresponding_json_file:
                            self._txts_with_corresponding_json_file[txt + ".txt"] += 1
                        else:
                            self._txts_with_corresponding_json_file[txt + ".txt"] = 1

    def find_txt_json_pairs(self) -> None:
        """
        Generates items to self._txt_json_pairs class variable as follows:
        self._txt_json_pairs[txt_filename] = filename
        for all txt files that have a corresponding json file in folder pointed by self._txt_and_json_folder class
        variable.

        :return: None
        """

        for txt_filename, number in self._txts_with_corresponding_json_file.items():
            if number > 1:
                print("Duplum: " + txt_filename)
                continue
            for filename in os.listdir(self._txt_and_json_folder):
                f = os.path.join(self._txt_and_json_folder, filename)
                if os.path.isfile(f) and f.endswith('.json'):
                    if txt_filename.replace(".txt", "") in filename:
                        self._txt_json_pairs[txt_filename] = filename

    def write_pairs(self) -> None:
        """
        Writes the txt - json pairs into PAIRS.txt file into the folder pointed by self._result_folder class variable.

        :return: None
        """

        with open(self._result_folder + "PAIRS.txt", 'w', encoding='utf-8') as f:
            for txt, json in self._txt_json_pairs.items():
                f.write(txt)
                f.write('\t')
                f.write(json)
                f.write('\r\n')
        return self._txt_json_pairs
