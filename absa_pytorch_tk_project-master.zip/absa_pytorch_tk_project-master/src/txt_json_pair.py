import json


class TxtJsonPair(object):
    """
    Osztály, ami tartalmazza a txt szövegét, és a hozzá tartozó json összes Entity es Relation tag-jét
    Metódusok:
        - start(): MINDIG meg kell hívni elsőnek az objektumon, mert ez állítja elő a self._entities, self._relations
                    listákat!!!
        - entities(): visszaad egy listát a txt-hez tartozó json-ben talált Entitiy -objektumokkal
        - relation(): visszaad egy listát a txt-hez tartozó json-ben talált Relation -objektumokkal

    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        Entitiy:    ET: e_14                                Position: 3996              Text: egy unokák nélküli összeszerelő ország
        Relation:   Emotion topic: ['e_5', [3898, 3919]]    Argument: [3901, 3904]
    """

    def __init__(self, txt_path, json_path):
        self._txt_path = txt_path
        self._json_path = json_path
        self._txt_text = ""
        self._entities = []         # list of Entity objects
        self._relations = []        # list of Relation objects

    def start(self) -> None:
        """
        Creates a list from both Entities and Relations belongs to the current txt, set these list as:
            - self._entities, and
            - self._relations
        Then reads the original text from the txt file to self._txt_text

        :return: None
        """
        with open(self._txt_path, 'r', encoding='utf8') as txt:
            self._txt_text = txt.readlines()
        with open(self._json_path, 'r', encoding='utf8') as json_file:
            json_content = json.load(json_file)
            entities_list_of_dicts = json_content['entities']
            relations_list_of_dicts = json_content['relations']
            for entity_dict in entities_list_of_dicts:
                et_type = entity_dict['classId']
                text = entity_dict['offsets'][0]['text']
                char_position_start = entity_dict['offsets'][0]['start']
                self._entities.append(Entity(et_type, char_position_start, text))
            for relation_dict in relations_list_of_dicts:
                connection_list = relation_dict["entities"]
                if '|e_14|' in connection_list[0] or '|e_14|' in connection_list[1]:
                    for elem in connection_list:
                        if '|e_14|' in elem:
                            argument_str = elem.split('|')[2]                                       # '209,228'
                            argument = [int(position) for position in argument_str.split(',')]      # integer konverzió a karakter pozciókra: [209, 228]
                        else:
                            emotion_topic = elem.split('|')[1:]
                            emotion_topic[1] = [int(position) for position in emotion_topic[1].split(',')]      # integer konverzió a karakter pozciókra
                    self._relations.append(Relation(emotion_topic, argument))

    @property
    def entities(self):
        return self._entities

    @property
    def relations(self):
        return self._relations

    @property
    def raw_text(self):
        return self._txt_text

    def __str__(self):
        entities_content = ""
        for entity in self._entities:
            entities_content += str(entity)
            entities_content += "\n"
        relations_content = ""
        for relation in self._relations:
            relations_content += str(relation)
            relations_content += "\n"
        return "Text: " + str(self._txt_text) + "\nEntities:\n" + entities_content + "\nRelations:\n" + \
               relations_content


class Entity(object):
    """
    Objektum, ami tárolja:
        - az emotion topic típusát,
        - kezdő karakterpozícióját
        - és szövegét

    Metódusai:
        getterek: et_type(), char_position_start(), text()

    Értékadás csak konstruktorban!!

    pl.:    ET: e_14    Position: 3996      Text: egy unokák nélküli összeszerelő ország

    """
    def __init__(self, et_type, char_position_start, text):
        self._et_type = et_type
        self._char_position_start = char_position_start
        self._text = text

    @property
    def et_type(self):
        return self._et_type

    @property
    def char_position_start(self):
        return self._char_position_start

    @property
    def text(self):
        return self._text

    def __str__(self):
        return "ET: " + self._et_type + " Position: " + str(self._char_position_start) + " Text: " + self._text


class Relation(object):
    """
    Objektum, ami tárolja:
        - az emotion topic típusát, és karakter pozícióját, amire az argumentum vonatkozik egy LISTÁBAN
        - az argumentum karakter pozciját egy LISTÁBAN

    Metódusai:
        getterek: emotion_topic(), argument()

    Értékadás csak konstruktorban!!

    pl.:    Emotion topic: ['e_5', [3898, 3919]]    Argument: [3901, 3904]

    """

    def __init__(self, emotion_topic, argument):
        self._emotion_topic = emotion_topic
        self._argument = argument

    @property
    def emotion_topic(self):
        return self._emotion_topic

    @property
    def argument(self):
        return self._argument

    def __str__(self):
        return "Emotion topic: " + str(self._emotion_topic) + " Argument: " + str(self._argument)
