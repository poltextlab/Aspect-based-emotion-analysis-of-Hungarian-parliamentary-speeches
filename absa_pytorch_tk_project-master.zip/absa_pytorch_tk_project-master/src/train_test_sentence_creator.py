from src.sentence_segmentation import Segmentation
from typing import List, Dict

"""
A BT legközelebbi ülésén részt vesz $T$ nemzetgazdasági miniszter is - közölték a lap érdeklődésére a szaktárcánál.
Matolcsy György
0
"""


def create_train_test_sentences(text_and_annotation_object, ET_SENTENCE_CLUSTERS_DICT):
    """

    :param text_and_annotation_object: object that stores the raw test, and all annotations (Entity and Relation) for a
    given txt file
    :return:
    """

    train_test_sentences_final = []

    relations = text_and_annotation_object.relations       # Emotion topic: ['e_2', [1406, 1511]] Argument: [1413, 1420]
    content = text_and_annotation_object.raw_text[0]       # raw text
    sentence_segmentor = Segmentation()
    sentences = sentence_segmentor.segment_text_to_sentences(content)               # segmented sentences
    sentence_indices = sentence_segmentor.calculate_indices(content, sentences)     # list of [start, end] lists

    for start_end in sentence_indices:
        relations_in_sentence = get_sentence_relations(relations, start_end)
        if relations_in_sentence:                                                   # if there are any relations in the sentence
            if len(relations_in_sentence) == 1:

                ET_SENTENCE_CLUSTERS_DICT, train_test_sentences = generate_train_test_sentence(start_end, content, relations_in_sentence, ET_SENTENCE_CLUSTERS_DICT)
                train_test_sentences_final.append(train_test_sentences)

            sentence_emotion_topic = ""
            more_than_one_emotion_topics = False
            for index, relation in enumerate(relations_in_sentence):
                if index == 0:
                    sentence_emotion_topic = relation.emotion_topic[0]
                else:
                    if relation.emotion_topic[0] != sentence_emotion_topic:
                        more_than_one_emotion_topics = True
            if not more_than_one_emotion_topics:

                ET_SENTENCE_CLUSTERS_DICT, train_test_sentences = generate_train_test_sentence(start_end, content, relations_in_sentence, ET_SENTENCE_CLUSTERS_DICT)
                train_test_sentences_final.append(train_test_sentences)

    return ET_SENTENCE_CLUSTERS_DICT, train_test_sentences_final


def generate_train_test_sentence(start_end, content, relations_in_sentence, ET_SENTENCE_CLUSTERS_DICT):

    sentence_emotion = relations_in_sentence[0].emotion_topic[0]
    sentence = content[start_end[0]: start_end[1]]
    train_test_sentences = []

    #tegyük a példák közé a mondatot annyiszor, ahány relation tartozik hozzá
    # az összes "variáns"-t, ami egy mondatból argumentum szerint létezik, eltesszük egy listába, a listát pedig az ET-k
    # szerint osztályzott dict-be

    instances_for_sentence = []

    for relation in relations_in_sentence:
        argument_positions = [relation.argument[0], relation.argument[1]]
        argument_text = content[argument_positions[0]:argument_positions[1]+1]

        # mondaton belüli pozíció
        relative_start = argument_positions[0] - start_end[0]
        relative_end = argument_positions[1] - start_end[0]
        # print(argument_text)
        # print(sentence)
        train_test_sentence = sentence[:relative_start] + "$T$" + sentence[relative_end + 1:]
        # instance: ['Ha $T$ így folytatják, 2020-ra Magyarország Európa szegényháza lesz.', 'önök', 'e_2']
        instance = [train_test_sentence, argument_text, sentence_emotion]
        train_test_sentences.append(instance)
        instances_for_sentence.append(instance)
        # print(instance)

    # print(instances_for_sentence)
    # {'e_5': [['$T$, negyedszázad után először kormányprogram nélkül választott miniszterelnököt az Országgyűlés.', 'Szombaton', 'e_5'],
    # ['Szombaton, negyedszázad után $T$ kormányprogram nélkül ... ]]

    ET_SENTENCE_CLUSTERS_DICT = Merge(ET_SENTENCE_CLUSTERS_DICT, train_test_sentences, sentence_emotion)

    return ET_SENTENCE_CLUSTERS_DICT, train_test_sentences


def get_sentence_relations(relations, start_end) -> List:

    relations_in_sentence = []
    for relation in relations:
        if relation.emotion_topic[1][0] >= start_end[0] and relation.emotion_topic[1][1] <= start_end[1]:
            relations_in_sentence.append(relation)

    return relations_in_sentence

def Merge(original, new_list_of_lists, sentence_emotion):
    # original: ET : [[instance1], [instance2]]
    # new: ET: [[[S1_instance1], [S1_instance2]], [[S2_instance1], [S2_instance2]], ...

    sentence_emotion = sentence_emotion.replace("e_", "")
    if len(original[sentence_emotion]) == 0:
        original[sentence_emotion] = [new_list_of_lists]
    else:
        original[sentence_emotion].append(new_list_of_lists)
    return original