import math
import random
import hu_core_news_lg

obligatory_POS = [["NOUN"], ["PRON"], ["PROPN"]]
filtered_ET_SENTENCE_CLUSTERS_DICT = {}


def generate(ET_SENTENCE_CLUSTERS_DICT, test_file, train_file):
    # select POS filtered arguments from original data
    init()
    select_POS_filtered(ET_SENTENCE_CLUSTERS_DICT)
    print("arguments' POS filtering done")
    train_set_number_of_instances = count_instances_per_emotion_topic()
    print("train test counts calculated")
    train_instances, test_instances = generate_train_test_sets(filtered_ET_SENTENCE_CLUSTERS_DICT, train_set_number_of_instances)
    write_instances(train_instances, train_file)
    write_instances(test_instances, test_file)


def write_instances(instances, tofile):
    with open(tofile, 'w', encoding='utf8') as output:
        for instance in instances:
            for line_ in instance:
                output.write(line_)
                output.write('\n')

def generate_train_test_sets(filtered_ET_SENTENCE_CLUSTERS_DICT, train_set_number_of_instances):
    train_instances = []
    test_instances = []
    for actual_et in range(1, 13):
        sentence_clusters = filtered_ET_SENTENCE_CLUSTERS_DICT[str(actual_et)]
        already_added = 0
        needed_test_sentences = train_set_number_of_instances[str(actual_et)]
        random.shuffle(sentence_clusters)
        breaked = False
        for cluster in sentence_clusters:       # cluster: sentence variants
            for index, sentence in enumerate(cluster):
                if already_added < needed_test_sentences:
                    test_instances.append(sentence)
                    already_added = already_added + 1
                else:
                    if index < len(cluster) and not breaked:
                        breaked = True
                        break
                    train_instances.append(sentence)
    return train_instances, test_instances

def count_instances_per_emotion_topic():
    counters = dict()
    for emotion_topic in filtered_ET_SENTENCE_CLUSTERS_DICT:
        list_of_clusters = filtered_ET_SENTENCE_CLUSTERS_DICT[emotion_topic] # cluster:[ sentence vaiants:[ instance:[  ...  ]]]
        sentences = 0
        for cluster in list_of_clusters:
            sentences += len(cluster)
        counters[str(emotion_topic)] = sentences
    for et, count in counters.items():
        if count > 0:
            counters[et] = math.ceil(count*0.2)
    return counters


def select_POS_filtered(ET_SENTENCE_CLUSTERS_DICT):
    obligatory_POS_list = [item for sublist in obligatory_POS for item in sublist]

    nlp = hu_core_news_lg.load()

    for emtion_topic, list_of_lists in ET_SENTENCE_CLUSTERS_DICT.items():
        all_data = ET_SENTENCE_CLUSTERS_DICT[emtion_topic]

        for cluster in all_data:        # sentence variants
            remaining_cluster = []
            for instance in cluster:    # sentence to inspect by argument POS-s
                doc = nlp(instance[1])
                pos_tags = []
                for sentence in doc.sents:
                    for token in sentence:
                        pos_tags.append(token.pos_)

                intersection = set(obligatory_POS_list).intersection(set(pos_tags))

                if not intersection:
                    continue
                else:
                    remaining_cluster.append(instance)

            if len(filtered_ET_SENTENCE_CLUSTERS_DICT[emtion_topic]) == 0:
                filtered_ET_SENTENCE_CLUSTERS_DICT[emtion_topic] = [remaining_cluster]
            else:
                filtered_ET_SENTENCE_CLUSTERS_DICT[emtion_topic].append(remaining_cluster)


def init():
    """

    :return:
    """

    # Create ET_SENTENCE_CLUSTERS_DICT, which contains all "variants" of a sentence, under the key of it's emotion topic
    # Each key contains a list of lists;
    # { '1': [[This is a bad $T$ and even worst timing, idea, e_2]]
    # }

    for i in range(1, 13):
        filtered_ET_SENTENCE_CLUSTERS_DICT[str(i)] = []