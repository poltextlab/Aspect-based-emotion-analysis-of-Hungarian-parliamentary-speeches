from preprocessors.sentence_splitter import SentenceSplitter
import re
from typing import List


class Segmentation(object):

    def segment_text_to_sentences(self, content: str) -> List:
        """
        Creates a list of sentences from raw text.

        :param content: raw text to process
        :return: list of sentences
        """

        splitter = SentenceSplitter(language='hu', non_breaking_prefix_file=str('resources/hu.txt'))

        sentences = splitter.split(content)
        # remove empty lines
        sentences = [sentence for sentence in sentences if sentence != ""]
        sentences = self.__filter_out_noise(sentences)
        return sentences

    def calculate_indices(self, raw_text: str, sentences: List) -> List:
        """
        Function to calculate the [start, end] character position (indices) of sentences in a raw text.

        :param raw_text: String with raw text
        :param sentences: List of already segmented sentences
        :return:
        """
        sentence_indices = []
        previous_end = 0

        for sentence in sentences:
            start = raw_text.index(sentence, previous_end)
            end = start + len(sentence)
            previous_end = end
            sentence_indices.append([start, end])
            # print(str(start) + " : " + str(end))
            # print(previous_end)
            # print(sentence)
            # print(raw_text[start:end])


        return sentence_indices


    def __filter_out_noise(self, sentences: List) -> List:
        """
        A common problem with sentence splitter is the creation of "fake" sentences, beginning with a loewr case letter.
        This function concatenates these sentence fragments into "real" ones.

        :param sentences:
        :return:
        """

        results = sentences
        results2 = []

        # kisbetűs "mondat" kezdések szűrése, ha kisbetűvel indul, akkor valójában az előző mondathoz kell join-olni!
        i = 0
        skip = 0

        while i < len(results):
            sentence = results[i]
            j = i + 1
            while j < len(results):
                if re.match("^[a-zöüóőúűéáí]", results[j]):
                    sentence += " "
                    sentence += results[j]
                    skip += 1
                    j += 1
                elif skip == 0:
                    j += 1
                    break
                else:
                    i += skip
                    skip = 0
                    break
            i += 1
            results2.append(sentence)

        return results2
